# 20-10_Flower
Happy Vietnamese Women's Day!  On this special day, I would like to express my sincere gratitude to all the women in Vietnam for their hard work, dedication, and strength. You are the backbone of our society, and we are so lucky to have you.  I would also like to take this opportunity to celebrate the beauty and strength of Vietnamese women. 
